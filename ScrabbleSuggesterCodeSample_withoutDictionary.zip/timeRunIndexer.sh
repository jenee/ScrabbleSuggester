echo "RUN 1"
time ./scrabble-indexer word_list_moby_crossword-flat/word_list_moby_crossword.flat.txt > outINDEXER
echo "RUN 2"
time ./scrabble-indexer word_list_moby_crossword-flat/word_list_moby_crossword.flat.txt > outINDEXER
echo "RUN 3"
time ./scrabble-indexer word_list_moby_crossword-flat/word_list_moby_crossword.flat.txt > outINDEXER
echo "RUN 4"
time ./scrabble-indexer word_list_moby_crossword-flat/word_list_moby_crossword.flat.txt > outINDEXER
echo "RUN 5"
time ./scrabble-indexer word_list_moby_crossword-flat/word_list_moby_crossword.flat.txt > outINDEXER
echo "RUN 6"
time ./scrabble-indexer word_list_moby_crossword-flat/word_list_moby_crossword.flat.txt > outINDEXER
echo "RUN 7"
time ./scrabble-indexer word_list_moby_crossword-flat/word_list_moby_crossword.flat.txt > outINDEXER
echo "RUN 8"
time ./scrabble-indexer word_list_moby_crossword-flat/word_list_moby_crossword.flat.txt > outINDEXER
echo "RUN 9"
time ./scrabble-indexer word_list_moby_crossword-flat/word_list_moby_crossword.flat.txt > outINDEXER
echo "RUN 10"
time ./scrabble-indexer word_list_moby_crossword-flat/word_list_moby_crossword.flat.txt > outINDEXER
echo "RUN 11"
time ./scrabble-indexer word_list_moby_crossword-flat/word_list_moby_crossword.flat.txt > outINDEXER


