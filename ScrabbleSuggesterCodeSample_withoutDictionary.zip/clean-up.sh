rm  ./IndexFiles/*
rm -d ./IndexFiles
rm ./*.class
