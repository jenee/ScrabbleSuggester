echo "RUN 1"
time ./scrabble-suggester "zygl" 5 
echo "RUN 2"
time ./scrabble-suggester "zygl" 5 
echo "RUN 3"
time ./scrabble-suggester "zygl" 5 
echo "RUN 4"
time ./scrabble-suggester "zygl" 5 
echo "RUN 5"
time ./scrabble-suggester "zygl" 5 
echo "RUN 6"
time ./scrabble-suggester "zygl" 5 
echo "RUN 7"
time ./scrabble-suggester "zygl" 5 
echo "RUN 8"
time ./scrabble-suggester "zygl" 5 
echo "RUN 9"
time ./scrabble-suggester "zygl" 5 
echo "RUN 10"
time ./scrabble-suggester "zygl" 5 
echo "RUN 11"
time ./scrabble-suggester "zygl" 5 
